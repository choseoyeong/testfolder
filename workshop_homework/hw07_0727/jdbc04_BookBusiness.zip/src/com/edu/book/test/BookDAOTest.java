package com.edu.book.test;

import com.edu.book.dao.impl.BookDAOImpl;

public class BookDAOTest {

	public static void main(String[] args) {
		BookDAOImpl dao = BookDAOImpl.getInstance();
		//메소드를 try{ catch안에서 하나씩 호출하면서 작업을 마무리 하시기 바랍니다.

	}
}
