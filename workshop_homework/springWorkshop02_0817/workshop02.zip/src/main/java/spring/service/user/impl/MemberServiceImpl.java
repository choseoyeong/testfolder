package spring.service.user.impl;

import spring.service.user.MemberService;

public class MemberServiceImpl implements MemberService{

}
