package com.edu.jdbc.test;

import java.sql.SQLException;

import com.edu.jdbc.dao.CustomerDAO;

import config.ServerInfo;

public class SimpleCustomerDAOTest1 {

	public static void main(String[] args) {
		
		CustomerDAO dao = new CustomerDAO();
		
		try {
			dao.addCustomer(222, "손흥민", "토트넘");
//			dao.deleteCustomer(111, "James", "NY");
//			dao.updateCustomer(111, "Jacop", "Brandon");
//			dao.printAllCustomer();
		} catch (SQLException e) {
			
		}
		
	} //main
	
	// static initialization block... --> main()보다 먼저 실행됨
	static {
		try {
			Class.forName(ServerInfo.DRIVER_NAME);
			System.out.println("1. 드라이버 로딩 성공...");
			
		} catch (ClassNotFoundException e) {
			System.out.println("드라이버 로딩 실패...");
		}
	}

}
