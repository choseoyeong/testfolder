package web.controller;

public interface Controller {
	String handle();
}
